package com.example.reto1_android.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.reto1_android.R;
import com.example.reto1_android.Thread.HiloAndroid;

import java.io.Serializable;
import clases.User;

/**
 * Activity Iniciar.
 * @author Ricardo
 */
public class IniciarActivity extends AppCompatActivity {
    EditText etNombreUsuario;
    EditText etContra;
    Button btnRegistrar;
    Button btnAcceder;

    /**
     * Al crear la actividad.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        etNombreUsuario = findViewById(R.id.etNombreUsuarioInicio);
        etContra = findViewById(R.id.etContraInicio);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        btnAcceder = findViewById(R.id.btnAcceder);
    }

    /**
     * Comprueba los datos, crea el hilo y analiza el resultado.
     * @param v Controlador sobre la que se ha ejecutado la acción.
     */
    public void clickOnbtnAcceder(View v) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setPositiveButton(android.R.string.ok, null);
        if(!isEmpty()){
            if(isNetworkAvailable()) {
                Object resultado = null;
                try {
                    HiloAndroid hilo = new HiloAndroid(2, new User(etNombreUsuario.getText()
                            .toString().trim(), etContra.getText().toString().trim()));
                    hilo.start();
                    hilo.join();
                    resultado = hilo.getRespuesta();
                } catch (Exception e) {
                    alertDialog.setMessage(R.string.error);
                    alertDialog.show();
                }
                if (resultado instanceof User) {

                    Intent intent = new Intent(this, PrincipalActivity.class);
                    intent.putExtra("user", (Serializable) resultado);
                    startActivity(intent);
                } else {
                    if (resultado == null) {
                        alertDialog.setMessage(R.string.huboError);
                    } else {
                        alertDialog.setMessage(analizaError((Integer) resultado));
                    }
                    alertDialog.show();
                }
            }else{
                alertDialog.setMessage(R.string.noInternet);
                alertDialog.show();
            }
        }else{
            alertDialog.setMessage(R.string.campoVacio);
            alertDialog.show();
        }
    }

    /**
     * Inicia la activity Registro.
     * @param v Controlador sobre la que se ha ejecutado la acción.
     */
    public void clickOnbtnRegistrar(View v) {
        Intent intent = new Intent(this, RegistroActivity.class);
        startActivity(intent);
    }

    /**
     * Comprueba que los campos de texto no esten vacios.
     * @return true si estan vacios.
     */
    public boolean isEmpty(){
        boolean esta = false;
        if(etNombreUsuario.getText().length() == 0 || etContra.getText().length() == 0){
            esta = true;
        }
        return esta;
    }

    /**
     * Comprueba si hay conexion a internet
     * @return true si hay conexion a internet
     */
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    /**
     * Analiza y devuelve una cadena para el usuario apropiada.
     * @param error Es el numero que identifica el error.
     * @return 1:LogicException, 2:EsperaCompletaException, 3:ServerException
     * 4:DAOException, 5:LoginIDException, 6:PasswordException
     */
    public String analizaError(Integer error) {
        String resultado = getString(R.string.huboError);
        switch (error) {
            case 1:
                resultado = getString(R.string.errorLogic);
                break;
            case 2:
                resultado = getString(R.string.errorEspera);
                break;
            case 3:
                resultado = getString(R.string.errorServer);
                break;
            case 4:
                resultado = getString(R.string.errorDAO);
                break;
            case 5:
                resultado = getString(R.string.errorIDLogin);
                break;
            case 6:
                resultado = getString(R.string.errorPassword);
                break;
        }
        return resultado;
    }
}